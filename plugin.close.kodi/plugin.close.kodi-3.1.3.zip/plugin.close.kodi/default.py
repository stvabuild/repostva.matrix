import os

def flawless():
		os._exit(1)
flawless()